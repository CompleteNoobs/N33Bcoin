#ifndef BITCOIN_CHAINPARAMSSEEDS_H
#define BITCOIN_CHAINPARAMSSEEDS_H
static SeedSpec6 pnSeed6_main[] = {};
static SeedSpec6 pnSeed6_test[] = {};
#endif // BITCOIN_CHAINPARAMSSEEDS_H
